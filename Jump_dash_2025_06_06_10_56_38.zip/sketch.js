function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let player;
let obstacles = [];
let score = 0;
let isJumping = false;
let gravity = 0.6;
let jumpStrength = 15;

function setup() {
  createCanvas(600, 400);
  player = new Player();
  setInterval(spawnObstacle, 1500); // Cria novos obstáculos a cada 1,5 segundos
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Atualiza e exibe obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    // Verifica colisão
    if (obstacles[i].hits(player)) {
      noLoop(); // Para o jogo se houver colisão
      textSize(32);
      fill(255, 0, 0);
      text('Game Over', width / 2 - 80, height / 2);
    }

    // Remove obstáculos que saíram da tela
    if (obstacles[i].offscreen()) {
      obstacles.splice(i, 1);
      score++;
    }
  }

  // Atualiza e exibe o jogador
  player.update();
  player.show();

  // Exibe a pontuação
  textSize(16);
  fill(0);
  text('Score: ' + score, 10, 20);
}

function keyPressed() {
  if (key === ' ') {
    if (!isJumping) {
      player.jump();
      isJumping = true;
    }
  }
}

// Classe do jogador
class Player {
  constructor() {
    this.x = 50;
    this.y = height - 50;
    this.size = 30;
    this.velocityY = 0;
  }

  jump() {
    this.velocityY = -jumpStrength; // Aplica a força do salto
  }

  update() {
    this.y += this.velocityY; // Atualiza a posição vertical
    this.velocityY += gravity; // Aplica a gravidade

    // Restringe o jogador ao chão
    if (this.y >= height - 50) {
      this.y = height - 50;
      this.velocityY = 0;
      isJumping = false; // Permite novos saltos
    }
  }

  show() {
    fill(0, 150, 255);
    rect(this.x, this.y, this.size, this.size); // Desenha o jogador
  }
}

// Classe do obstáculo
class Obstacle {
  constructor() {
    this.x = width;
    this.y = height - 50;
    this.size = random(20, 60);
    this.speed = 6;
  }

  update() {
    this.x -= this.speed; // Move o obstáculo para a esquerda
  }

  show() {
    fill(255, 0, 0);
    rect(this.x, this.y - this.size, 20, this.size); // Desenha o obstáculo
  }

  offscreen() {
    return this.x < -20; // Verifica se o obstáculo saiu da tela
  }

  hits(player) {
    return (
      player.x < this.x + 20 &&
      player.x + player.size > this.x &&
      player.y < this.y &&
      player.y + player.size > this.y - this.size
    );
  }
}

// Função para criar novos obstáculos
function spawnObstacle() {
  obstacles.push(new Obstacle());
}
